package com.example.firebaseloginsignup

data class User(var userName : String? = null, var nama :String ?= null, var kode : String ?= null,
                var jenis : String ?= null, var jumlah :String ? =null,
                var tanggal : String ?=null)
