package com.example.firebaseloginsignup

data class Penjualan (
    val userName : String?,
    val nama : String,
    val jenis :String,
    val kode :String,
    val jumlah :String,
    val tanggal :String
)